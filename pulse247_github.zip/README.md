# Pulse 24/7 — Live Token Website

This repository hosts the **Pulse 24/7 (PLSE)** website.

## Deployment (Free via GitHub Pages)

1. Create a GitHub repository (e.g., `pulse247-site`).
2. Upload `index.html` to the repository root.
3. Go to **Settings → Pages → Source → main branch** and click Save.
4. Your site will be live at `https://<username>.github.io/pulse247-site/`.
